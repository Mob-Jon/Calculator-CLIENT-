﻿namespace CalculatorApp
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SubtractBtn = new System.Windows.Forms.Button();
            this.multiplyBtn = new System.Windows.Forms.Button();
            this.divideBtn = new System.Windows.Forms.Button();
            this.txtBoxFirstNum = new System.Windows.Forms.TextBox();
            this.txtBoxSecondNum = new System.Windows.Forms.TextBox();
            this.lblFirstNum = new System.Windows.Forms.Label();
            this.lblSecondNum = new System.Windows.Forms.Label();
            this.AddBtn = new System.Windows.Forms.Button();
            this.txtBoxResultDisplay = new System.Windows.Forms.TextBox();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // SubtractBtn
            // 
            this.SubtractBtn.Location = new System.Drawing.Point(164, 162);
            this.SubtractBtn.Name = "SubtractBtn";
            this.SubtractBtn.Size = new System.Drawing.Size(75, 23);
            this.SubtractBtn.TabIndex = 1;
            this.SubtractBtn.Text = "Subtract";
            this.SubtractBtn.UseVisualStyleBackColor = true;
            this.SubtractBtn.Click += new System.EventHandler(this.SubtractBtn_Click);
            // 
            // multiplyBtn
            // 
            this.multiplyBtn.Location = new System.Drawing.Point(50, 211);
            this.multiplyBtn.Name = "multiplyBtn";
            this.multiplyBtn.Size = new System.Drawing.Size(75, 23);
            this.multiplyBtn.TabIndex = 2;
            this.multiplyBtn.Text = "Multiply";
            this.multiplyBtn.UseVisualStyleBackColor = true;
            this.multiplyBtn.Click += new System.EventHandler(this.multiplyBtn_Click);
            // 
            // divideBtn
            // 
            this.divideBtn.Location = new System.Drawing.Point(164, 211);
            this.divideBtn.Name = "divideBtn";
            this.divideBtn.Size = new System.Drawing.Size(75, 23);
            this.divideBtn.TabIndex = 3;
            this.divideBtn.Text = "Divide";
            this.divideBtn.UseVisualStyleBackColor = true;
            this.divideBtn.Click += new System.EventHandler(this.divideBtn_Click);
            // 
            // txtBoxFirstNum
            // 
            this.txtBoxFirstNum.Location = new System.Drawing.Point(139, 77);
            this.txtBoxFirstNum.Name = "txtBoxFirstNum";
            this.txtBoxFirstNum.Size = new System.Drawing.Size(100, 20);
            this.txtBoxFirstNum.TabIndex = 4;
            this.txtBoxFirstNum.Validating += new System.ComponentModel.CancelEventHandler(this.txBoxFirstNum_Validating);
            // 
            // txtBoxSecondNum
            // 
            this.txtBoxSecondNum.Location = new System.Drawing.Point(139, 114);
            this.txtBoxSecondNum.Name = "txtBoxSecondNum";
            this.txtBoxSecondNum.Size = new System.Drawing.Size(100, 20);
            this.txtBoxSecondNum.TabIndex = 5;
            this.txtBoxSecondNum.Validating += new System.ComponentModel.CancelEventHandler(this.txtBoxSecondNum_Validating);
            // 
            // lblFirstNum
            // 
            this.lblFirstNum.AutoSize = true;
            this.lblFirstNum.Location = new System.Drawing.Point(47, 80);
            this.lblFirstNum.Name = "lblFirstNum";
            this.lblFirstNum.Size = new System.Drawing.Size(66, 13);
            this.lblFirstNum.TabIndex = 6;
            this.lblFirstNum.Text = "First Number";
            // 
            // lblSecondNum
            // 
            this.lblSecondNum.AutoSize = true;
            this.lblSecondNum.Location = new System.Drawing.Point(49, 117);
            this.lblSecondNum.Name = "lblSecondNum";
            this.lblSecondNum.Size = new System.Drawing.Size(84, 13);
            this.lblSecondNum.TabIndex = 7;
            this.lblSecondNum.Text = "Second Number";
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(52, 162);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(75, 23);
            this.AddBtn.TabIndex = 8;
            this.AddBtn.Text = "Add";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // txtBoxResultDisplay
            // 
            this.txtBoxResultDisplay.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtBoxResultDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxResultDisplay.Location = new System.Drawing.Point(50, 21);
            this.txtBoxResultDisplay.Multiline = true;
            this.txtBoxResultDisplay.Name = "txtBoxResultDisplay";
            this.txtBoxResultDisplay.ReadOnly = true;
            this.txtBoxResultDisplay.Size = new System.Drawing.Size(189, 38);
            this.txtBoxResultDisplay.TabIndex = 9;
            this.txtBoxResultDisplay.Text = "0";
            this.txtBoxResultDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.txtBoxResultDisplay);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.lblSecondNum);
            this.Controls.Add(this.lblFirstNum);
            this.Controls.Add(this.txtBoxSecondNum);
            this.Controls.Add(this.txtBoxFirstNum);
            this.Controls.Add(this.divideBtn);
            this.Controls.Add(this.multiplyBtn);
            this.Controls.Add(this.SubtractBtn);
            this.Name = "Calculator";
            this.Text = "Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SubtractBtn;
        private System.Windows.Forms.Button multiplyBtn;
        private System.Windows.Forms.Button divideBtn;
        private System.Windows.Forms.TextBox txtBoxFirstNum;
        private System.Windows.Forms.TextBox txtBoxSecondNum;
        private System.Windows.Forms.Label lblFirstNum;
        private System.Windows.Forms.Label lblSecondNum;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox txtBoxResultDisplay;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

