﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CalculatorApp
{
    public partial class Calculator : Form
    {
        private float numOne;
        private float numTwo;
        private float rs;

        ServiceReference.ServiceSoapClient service = new ServiceReference.ServiceSoapClient();

        public Calculator()
        {
            InitializeComponent();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            rs = service.Add(numOne, numTwo);

            txtBoxResultDisplay.Text = rs.ToString();
            
        }

        private void SubtractBtn_Click(object sender, EventArgs e)
        {
            rs = service.Subtract(numOne, numTwo);

            txtBoxResultDisplay.Text = rs.ToString();
        }

        private void multiplyBtn_Click(object sender, EventArgs e)
        {
            rs = service.Multiply(numOne, numTwo);

            txtBoxResultDisplay.Text = rs.ToString();
        }

        private void divideBtn_Click(object sender, EventArgs e)
        {
            rs = service.Divide(numOne, numTwo);

            txtBoxResultDisplay.Text = rs.ToString();
        }

        private void txtBoxSecondNum_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtBoxSecondNum.Text))
            {
                e.Cancel = true;
                txtBoxSecondNum.Focus();
                errorProvider.SetError(txtBoxSecondNum, "Input should not be empty!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtBoxSecondNum, "");
                numTwo = Convert.ToInt32(txtBoxSecondNum.Text);
            }
        }

        private void txBoxFirstNum_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtBoxFirstNum.Text))
            {
                e.Cancel = true;
                txtBoxFirstNum.Focus();
                errorProvider.SetError(txtBoxFirstNum, "Input should not be empty!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtBoxFirstNum, "");
                numOne = Convert.ToInt32(txtBoxFirstNum.Text);
            }
        }

    }
}
